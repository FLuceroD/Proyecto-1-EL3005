x = [ 0 0 1 1 0 0 0 0 0 0 0 ];
y = [ 0 0 0 0 0 0 1 1 0 0 0 ];
N = length(x);
n = 0:N-1;

clf
subplot(1,2,1)
stem(n,x)
titulo1 = title('Se�al 1: x(n)');
ejex1 = xlabel('n');
ejey1 = ylabel('x(n)');
set(ejex1,'Fontsize',18)
set(ejey1,'Fontsize',18)
set(titulo1,'Fontsize',20)
ylim([0 1.2])

subplot(1,2,2)
stem(n,y)
titulo2 = title('Se�al 2: y(n) = x(n-4)');
ejex2 = xlabel('n');
ejey2 = ylabel('y(n)');
set(ejex2,'Fontsize',18)
set(ejey2,'Fontsize',18)
set(titulo2,'Fontsize',20)
ylim([0 1.2])
hold off

r1 = correlacion_cruzada(x,y);
r2 = correlacion_cruzada(y,x);
l = -N+1:N-1;

figure(2)
subplot(1,2,1)
stem(l,r1)
titulo3 = title('r_{xy}');
ejey3 = ylabel('Correlacion cruzada (x,y)');
ejex3 = xlabel('l');
set(ejex3,'Fontsize',18)
set(ejey3,'Fontsize',18)
set(titulo3,'Fontsize',20)
ylim([0 2.2])

subplot(1,2,2)
stem(l,r2)
titulo4 = title('r_{yx}');
ejey4 = ylabel('Correlacion cruzada (y,x)');
ejex4 = xlabel('l');
set(ejex4,'Fontsize',18)
set(ejey4,'Fontsize',18)
set(titulo4,'Fontsize',20)
ylim([0 2.2])